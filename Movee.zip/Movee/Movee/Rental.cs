﻿public class Rental
{
    private Movie _movie;
    private Customer _customer;
    private DateTime _rentalDate;

    public Rental(Movie movie, Customer customer)
    {
        _movie = movie;
        _customer = customer;
        _rentalDate = DateTime.Now;
    }

    public void CompleteRental()
    {
        _customer.RentMovie(_movie);
        Console.WriteLine($"Rental completed on {_rentalDate} for {_customer} with movie {_movie}");
    }

    public void ReturnRental()
    {
        _customer.ReturnMovie(_movie);
        Console.WriteLine($"Movie {_movie} has been returned.");
    }
}
