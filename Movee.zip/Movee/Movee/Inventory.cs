﻿using System.Collections.Generic;

public class Inventory
{
    private List<Movie> _movies;

    public Inventory()
    {
        _movies = new List<Movie>();
    }

    public void AddMovie(Movie movie)
    {
        _movies.Add(movie);
        Console.WriteLine($"{movie} has been added to the inventory.");
    }

    public void RemoveMovie(Movie movie)
    {
        if (_movies.Contains(movie))
        {
            _movies.Remove(movie);
            Console.WriteLine($"{movie} has been removed from the inventory.");
        }
        else
        {
            Console.WriteLine("Movie not found in inventory.");
        }
    }

    public void DisplayAvailableMovies()
    {
        Console.WriteLine("Available Movies:");
        foreach (var movie in _movies)
        {
            movie.GetMovieDetails();
        }
    }
}
