﻿public class Transaction
{
    private Customer _customer;
    private Movie _movie;
    private DateTime _transactionDate;
    private string _transactionType; 

    public Transaction(Customer customer, Movie movie, string transactionType)
    {
        _customer = customer;
        _movie = movie;
        _transactionDate = DateTime.Now;
        _transactionType = transactionType;
    }

    public void LogTransaction()
    {
        string action = _transactionType == "Rent" ? "rented" : "returned";
        Console.WriteLine($"{_customer} has {action} {_movie} on {_transactionDate}");
    }
}
