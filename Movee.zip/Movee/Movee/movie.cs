﻿public class Movie
{
    private string _title;
    private string _genre;
    private bool _isAvailable;

    public Movie(string title, string genre)
    {
        _title = title;
        _genre = genre;
        _isAvailable = true; 
    }

    public bool IsAvailable
    {
        get { return _isAvailable; }
    }

    public void RentMovie()
    {
        if (_isAvailable)
        {
            _isAvailable = false;
            Console.WriteLine($"{_title} has been rented.");
        }
        else
        {
            Console.WriteLine($"{_title} is currently unavailable.");
        }
    }

    public void CheckAvailability()
    {
        string availabilityStatus = _isAvailable ? "available" : "unavailable";
        Console.WriteLine($"{_title} is currently {availabilityStatus}.");
    }

    public void ReturnMovie()
    {
        _isAvailable = true;
        Console.WriteLine($"{_title} has been returned and is now available.");
    }

    public void GetMovieDetails()
    {
        Console.WriteLine($"Title: {_title}, Genre: {_genre}, Available: {_isAvailable}");
    }
}
