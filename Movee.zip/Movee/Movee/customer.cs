﻿using System.Collections.Generic;

public class Customer
{
    private string _name;
    private List<Movie> _rentedMovies;

    public Customer(string name)
    {
        _name = name;
        _rentedMovies = new List<Movie>();
    }

    public void RentMovie(Movie movie)
    {
        if (movie.IsAvailable)
        {
            movie.RentMovie();
            _rentedMovies.Add(movie);
        }
        else
        {
            Console.WriteLine($"{movie} cannot be rented by {_name}.");
        }
    }

    public void ReturnMovie(Movie movie)
    {
        if (_rentedMovies.Contains(movie))
        {
            movie.ReturnMovie();
            _rentedMovies.Remove(movie);
        }
        else
        {
            Console.WriteLine($"{_name} did not rent this movie.");
        }
    }

    public void GetCustomerDetails()
    {
        Console.WriteLine($"Customer: {_name}");
        if (_rentedMovies.Count == 0)
        {
            Console.WriteLine("No rented movies.");
        }
        else
        {
            Console.WriteLine("Rented Movies:");
            foreach (var movie in _rentedMovies)
            {
                movie.GetMovieDetails();
            }
        }
    }
}
