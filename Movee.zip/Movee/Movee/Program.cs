﻿public class Program
{
    public static void Main(string[] args)
    {
        Inventory inventory = new Inventory();

        Movie movie1 = new Movie("Inception", "Sci-Fi");
        Movie movie2 = new Movie("The Godfather", "Crime");
        inventory.AddMovie(movie1);
        inventory.AddMovie(movie2);

        inventory.DisplayAvailableMovies();

        Customer customer = new Customer("John Doe");

        Rental rental1 = new Rental(movie1, customer);
        rental1.CompleteRental();

        Transaction transaction1 = new Transaction(customer, movie1, "Rent");
        transaction1.LogTransaction();

        rental1.ReturnRental();

        Transaction transaction2 = new Transaction(customer, movie1, "Return");
        transaction2.LogTransaction();

        inventory.RemoveMovie(movie1);

        inventory.DisplayAvailableMovies();
    }
}
