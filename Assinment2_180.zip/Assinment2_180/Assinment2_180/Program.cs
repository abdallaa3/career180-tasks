﻿using System;

class Program
{
    static void Main()
    {
        int numberOfStudents = 2;
        int numberOfSubjects = 4;

        int[] studentIDs = new int[numberOfStudents];
        int[,] studentGrades = new int[numberOfStudents, numberOfSubjects];

        InputStudentData(studentIDs, studentGrades, numberOfSubjects);

        Console.WriteLine("Grade Evaluation for Each Subject:");
        EvaluateSubjectGrades(studentGrades, numberOfSubjects);

        Console.WriteLine("\nTotal Grade Evaluation for Each Student:");
        EvaluateTotalGrades(studentIDs, studentGrades, numberOfSubjects);

        Console.WriteLine("\nStudents Who Failed in More Than Two Subjects:");
        FindFailedStudents(studentIDs, studentGrades, numberOfSubjects);
    }

    static void InputStudentData(int[] studentIDs, int[,] studentGrades, int numberOfSubjects)
    {
        for (int i = 0; i < studentIDs.Length; i++)
        {
            Console.WriteLine($"Enter ID for student {i + 1}: ");
            studentIDs[i] = int.Parse(Console.ReadLine());

            for (int j = 0; j < numberOfSubjects; j++)
            {
                Console.WriteLine($"Enter grade for subject {j + 1} for student {studentIDs[i]}:");
                studentGrades[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    // Method to evaluate and print grades for each subject
    static void EvaluateSubjectGrades(int[,] studentGrades, int numberOfSubjects)
    {
        for (int i = 0; i < studentGrades.GetLength(0); i++)
        {
            Console.WriteLine($"\nStudent {i + 1} Grades:");
            for (int j = 0; j < numberOfSubjects; j++)
            {
                string gradeEvaluation = GradeEvaluation(studentGrades[i, j]);
                Console.WriteLine($"Subject {j + 1}: Grade = {studentGrades[i, j]}%, Evaluation = {gradeEvaluation}");
            }
        }
    }

    static void EvaluateTotalGrades(int[] studentIDs, int[,] studentGrades, int numberOfSubjects)
    {
        for (int i = 0; i < studentGrades.GetLength(0); i++)
        {
            int totalGrade = 0;
            for (int j = 0; j < numberOfSubjects; j++)
            {
                totalGrade += studentGrades[i, j];
            }

            // Calculate the average grade
            double averageGrade = (double)totalGrade / numberOfSubjects;
            string totalEvaluation = GradeEvaluation(averageGrade);

            Console.WriteLine($"Student ID: {studentIDs[i]} - Total Average Grade = {averageGrade}%, Evaluation = {totalEvaluation}");
        }
    }

    static void FindFailedStudents(int[] studentIDs, int[,] studentGrades, int numberOfSubjects)
    {
        for (int i = 0; i < studentGrades.GetLength(0); i++)
        {
            int failCount = 0;

            for (int j = 0; j < numberOfSubjects; j++)
            {
                if (studentGrades[i, j] < 50)
                {
                    failCount++;
                }
            }

            if (failCount > 2)
            {
                Console.WriteLine($"Student ID: {studentIDs[i]} failed in {failCount} subjects.");
            }
        }
    }

    // Method to evaluate grade
    static string GradeEvaluation(double grade)
    {
        if (grade >= 85)
            return "A";
        else if (grade >= 70)
            return "B";
        else if (grade >= 65)
            return "C";
        else if (grade >= 50)
            return "D";
        else
            return "F";
    }
}
