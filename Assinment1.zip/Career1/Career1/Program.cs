﻿using System;

class Program
{
    static void Main()
    {
        int num1, num2, choice;
        bool exit = false;

        // Input the two integers
        Console.Write("Enter the first integer: ");
        num1 = int.Parse(Console.ReadLine());

        Console.Write("Enter the second integer: ");
        num2 = int.Parse(Console.ReadLine());

        // Display the menu and perform operations based on user choice
        while (!exit)
        {
            Console.WriteLine("\nHere are the options:");
            Console.WriteLine("1 - Addition");
            Console.WriteLine("2 - Subtraction");
            Console.WriteLine("3 - Multiplication");
            Console.WriteLine("4 - Division");
            Console.WriteLine("5 - Exit");

            Console.Write("Input your choice: ");
            choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine($"The sum of {num1} and {num2} is: {num1 + num2}");
                    break;
                case 2:
                    Console.WriteLine($"The difference between {num1} and {num2} is: {num1 - num2}");
                    break;
                case 3:
                    Console.WriteLine($"The multiplication of {num1} and {num2} is: {num1 * num2}");
                    break;
                case 4:
                    if (num2 != 0)
                        Console.WriteLine($"The division of {num1} by {num2} is: {num1 / num2}");
                    else
                        Console.WriteLine("Error: Division by zero is not allowed.");
                    break;
                case 5:
                    exit = true;
                    Console.WriteLine("Exiting the program.");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please choose a valid option.");
                    break;
            }
        }
    }
}
