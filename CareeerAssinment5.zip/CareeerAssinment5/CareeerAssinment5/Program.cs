﻿namespace CareeerAssinment5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Doctor drAhmed = new Doctor { Name = "Dr. Ahmed", Role = "Doctor" };

            Assistant assistant = new Assistant { Name = "Sarah", Role = "Assistant" };

            Schedule drSchedule = new Schedule
            {
                DrName = drAhmed.Name,
                AvailableDates = new List<DateTime> { DateTime.Today.AddDays(1), DateTime.Today.AddDays(2) },
                AvailableTimeSlots = new List<TimeSpan> { new TimeSpan(9, 0, 0), new TimeSpan(11, 0, 0) }
            };

            ClinicController clinicController = new ClinicController();
            clinicController.DisplayAvailableSchedule(drSchedule);

            Appointment appointment1 = new Appointment
            {
                AppointmentId = 1,
                CustomerName = "John Doe",
                Date = DateTime.Today.AddDays(1),
                Time = new TimeSpan(9, 0, 0),
                Status = "Pending"
            };

            assistant.ReceiveAppointments(appointment1);
            Console.WriteLine($"Appointment Status: {appointment1.Status}");

            drAhmed.ApproveAppointments(appointment1);
            Console.WriteLine($"Appointment Status: {appointment1.Status}");

            assistant.FollowUpAppointments(appointment1);
            Console.WriteLine($"Appointment Status: {appointment1.Status}");
        }
    }
}
