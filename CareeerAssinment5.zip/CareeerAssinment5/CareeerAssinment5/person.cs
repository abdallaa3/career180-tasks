﻿public abstract class Person
{
    public string Name { get; set; }
    public string Role { get; set; }

    public abstract void ManageAppointments();
}

public class Doctor : Person
{
    public override void ManageAppointments()
    {
        Console.WriteLine("Doctor managing appointments.");
    }

    public void ApproveAppointments(Appointment appointment)
    {
        appointment.ApproveAppointment();
    }
}

public class Assistant : Person
{
    public override void ManageAppointments()
    {
        Console.WriteLine("Assistant managing appointments.");
    }

    public void ReceiveAppointments(Appointment appointment)
    {
        appointment.ChangeStatus("Received");
    }

    public void FollowUpAppointments(Appointment appointment)
    {
        appointment.FollowUpAppointment();
    }
}
