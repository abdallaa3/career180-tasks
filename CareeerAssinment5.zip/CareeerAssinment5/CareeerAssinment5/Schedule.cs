﻿public class Schedule
{
    public string DrName { get; set; }
    public List<DateTime> AvailableDates { get; set; }
    public List<TimeSpan> AvailableTimeSlots { get; set; }

    public void SetAvailableDates(List<DateTime> dates)
    {
        AvailableDates = dates;
    }

    public void SetAvailableTimeSlots(List<TimeSpan> timeSlots)
    {
        AvailableTimeSlots = timeSlots;
    }
}
