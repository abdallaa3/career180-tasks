﻿public class ClinicController
{
    public void CreateAppointment(Appointment appointment)
    {
        Console.WriteLine("Appointment created for " + appointment.CustomerName);
    }

    public void DisplayAvailableSchedule(Schedule schedule)
    {
        Console.WriteLine("Doctor's available dates: " + string.Join(", ", schedule.AvailableDates));
        Console.WriteLine("Available time slots: " + string.Join(", ", schedule.AvailableTimeSlots));
    }

    public void ManageAppointments()
    {
    }
}
